# สถาณที่ถ่ายทำ

A Pen created on CodePen.

Original URL: [https://codepen.io/aotrwhqz-the-looper/pen/MYamgLx](https://codepen.io/aotrwhqz-the-looper/pen/MYamgLx).

